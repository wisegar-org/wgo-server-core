declare module "@ckeditor/ckeditor5-vue" {}
declare module "@ckeditor/ckeditor5-build-decoupled-document" {}
