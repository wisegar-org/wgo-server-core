import enUS from "./enUS";
import itCH from "./itCH";

export default {
  "en-US": enUS,
  "it-CH": itCH,
};
