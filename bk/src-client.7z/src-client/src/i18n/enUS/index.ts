// This is just an example,
// so you can safely delete all default props below

const enUS = {
  failed: "Action failed",
  success: "Action was successful",
};

export default enUS;
