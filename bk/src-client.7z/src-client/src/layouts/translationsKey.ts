export const translations = {
  APP_TITLE: "WGO_TITLE",
};
