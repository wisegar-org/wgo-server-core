<template>
  <ContactForm @onSend="onSubmit" :showLoade="showLoader" />
</template> 

<script lang="ts" src="./ComitatoContactForm.ts" />